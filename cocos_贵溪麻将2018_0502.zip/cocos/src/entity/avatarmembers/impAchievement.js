"use strict";
/*-----------------------------------------------------------------------------------------
												interface
-----------------------------------------------------------------------------------------*/
var impAchievement = KBEngine.Avatar.extend({
	__init__ : function()
	{
		this._super();
	},

	// pushSignInNum : function(signInNum){
	// 	this.signInNum = signInNum;
	// 	if(h1global.curUIMgr.gamehall_ui && h1global.curUIMgr.gamehall_ui.is_show){
	// 		h1global.curUIMgr.gamehall_ui.update_signin_content(signInNum);
	// 	}
	// },
    //
	// signIn : function(){
	// 	this.baseCall("signIn");
	// },
    //
	// signInFailed : function(){
	// 	var tips = "您今天已经签到过了！再签到" + (const_val.SIGNIN_MAX - this.signInNum) + "天即可获得一张房卡。";
	// 	h1global.globalUIMgr.info_ui.show_by_info(tips, cc.size(300, 200));
	// }
});
