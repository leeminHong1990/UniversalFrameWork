# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *
import const
from classutils import checkEntityID


class iRoomOperation(object):
	""" 玩家游戏相关 """

	def __init__(self):
		pass

	def enterRoomSucceed(self, idx, info):
		if getattr(self, 'client', None):
			self.client.enterRoomSucceed(idx, info)

	def othersEnterRoom(self, player_info):
		if getattr(self, 'client', None):
			self.client.othersEnterRoom(player_info)

	def othersQuitRoom(self, idx):
		if getattr(self, 'client', None):
			self.client.othersQuitRoom(idx)

	# c2s
	@checkEntityID
	def quitRoom(self, callerEntityID):
		self.room and self.room.reqLeaveRoom(self)

	def quitRoomSucceed(self):
		DEBUG_MSG('avatar[%d] quit room succeed!' % self.userId)
		self.room = None
		if getattr(self, 'client', None):
			self.client.quitRoomSucceed()

		# 不在场景中了, 直接销毁
		self.destroy()

	def quitRoomFailed(self, err):
		if getattr(self, 'client', None):
			self.client.quitRoomFailed(err)

	def startGame(self, dealer_idx, tile_list, wreaths_list, kingTiles, prevailing_wind, player_wind_list, diceList):
		if getattr(self, 'client', None):
			self.client.startGame(dealer_idx, tile_list, wreaths_list, kingTiles, prevailing_wind, player_wind_list, diceList)

	def postOperation(self, idx, aid, tile_list):
		if getattr(self, 'client', None):
			self.client.postOperation(idx, aid, tile_list)

	def postWinOperation(self, idx, aid, result):
		if getattr(self, 'client', None):
			self.client.postWinOperation(idx, aid, result)

	def postMultiOperation(self, idx_list, aid_list, tile_list):
		if getattr(self, 'client', None):
			self.client.postMultiOperation(idx_list, aid_list, tile_list)

	# c2s
	@checkEntityID
	def doOperation(self, callerEntityID, aid, tile_list):
		if self.room:
			self.room.doOperation(self, aid, tile_list)

	def doOperationFailed(self, err):
		if getattr(self, 'client', None):
			self.client.doOperationFailed(err)

	def waitForOperation(self, aid_list, tile_list):
		if getattr(self, 'client', None):
			self.client.waitForOperation(aid_list, tile_list)

	# c2s
	@checkEntityID
	def confirmOperation(self, callerEntityID, aid, tile_list):
		if self.room:
			self.room.confirmOperation(self, aid, tile_list)

	def roundResult(self, round_info):
		if getattr(self, 'client', None):
			self.client.roundResult(round_info)

	def finalResult(self, player_info_list, round_info):
		self.room = None
		if getattr(self, 'client', None):
			self.client.finalResult(player_info_list, round_info)

	def	subtotalResult(self, player_info_list):
		self.room = None
		if getattr(self, 'client', None):
			self.client.subtotalResult(player_info_list)

	# c2s
	@checkEntityID
	def prepare(self, callerEntityID):
		if self.room:
			self.room.client_prepare(self)


	def readyForNextRound(self, idx):
		if getattr(self, 'client', None):
			self.client.readyForNextRound(idx)

	# c2s
	@checkEntityID
	def sendEmotion(self, callerEntityID, eid):
		if self.room:
			self.room.sendEmotion(self, eid)

	# c2s
	@checkEntityID
	def sendMsg(self, callerEntityID, mid, msg):
		if self.room:
			self.room.sendMsg(self, mid, msg)

	# c2s
	@checkEntityID
	def sendExpression(self, callerEntityID, fromIdx, toIdx, eid):
		if self.room:
			self.room.sendExpression(self, fromIdx, toIdx, eid)

	# c2s
	@checkEntityID
	def sendVoice(self, callerEntityID, url):
		if self.room:
			self.room.sendVoice(self, url)

	# c2s
	@checkEntityID
	def sendAppVoice(self, callerEntityID, url, time):
		if self.room:
			self.room.sendAppVoice(self, url, time)

	def recvEmotion(self, idx, eid):
		if getattr(self, 'client', None):
			self.client.recvEmotion(idx, eid)

	def recvMsg(self, idx, mid, msg):
		if getattr(self, 'client', None):
			self.client.recvMsg(idx, mid, msg)

	def recvExpression(self, fromIdx, toIdx, eid):
		if getattr(self, 'client', None):
			self.client.recvExpression(fromIdx, toIdx, eid)

	def recvVoice(self, idx, url):
		if getattr(self, 'client', None):
			self.client.recvVoice(idx, url)

	def recvAppVoice(self, idx, url, time):
		if getattr(self, 'client', None):
			self.client.recvAppVoice(idx, url, time)

	def handleReconnect(self, rec_room_info):
		if getattr(self, 'client', None):
			self.client.handleReconnect(rec_room_info)

	# c2s
	@checkEntityID
	def applyDismissRoom(self, callerEntityID):
		""" 申请解散房间 """
		if self.room:
			self.room.apply_dismiss_room(self)

	def req_dismiss_room(self, idx):
		""" 广播有人申请解散房间 """
		if getattr(self, 'client', None):
			# DEBUG_MSG("call client reqDismissRoom {0}".format(idx))
			self.client.reqDismissRoom(idx)

	# c2s
	@checkEntityID
	def voteDismissRoom(self, callerEntityID, vote):
		""" 解散房间投票操作 """
		if self.room:
			self.room.vote_dismiss_room(self, vote)

	def vote_dismiss_result(self, idx, vote):
		""" 广播投票结果 """
		if getattr(self, 'client', None):
			# DEBUG_MSG("call client voteDismissResult {0}->{1}".format(idx, vote))
			self.client.voteDismissResult(idx, vote)

	# s2c
	def notifyPlayerOnlineStatus(self, idx, status):
		""" 玩家上线, 下线通知 """
		DEBUG_MSG("call client notifyPlayerOnlineStatus {0}->{1}".format(idx, status))
		if getattr(self, 'client', None):
			self.client.notifyPlayerOnlineStatus(idx, status)

	# c2s
	@checkEntityID
	def setDiscardState(self, callerEntityID, state):
		"""玩家出牌状态"""
		pass
		# self.room and self.room.setDiscardState(self, state)

	def postPlayerDiscardState(self, idx, state):
		"""广播玩家出牌状态"""
		getattr(self, 'client', None) and self.client.postPlayerDiscardState(idx, state)

	def showWaitOperationTime(self):
		getattr(self, 'client', None) and self.client.showWaitOperationTime()