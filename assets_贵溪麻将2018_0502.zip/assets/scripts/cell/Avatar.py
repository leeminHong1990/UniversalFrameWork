# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *
import importlib
from interfaces.EntityCommon import EntityCommon
from avatarmembers.iRoomOperation import iRoomOperation
from classutils import MergePropertiesAndMethod
import const

class Avatar(KBEngine.Entity,
			 EntityCommon,
			 iRoomOperation):

	def __init__(self):
		KBEngine.Entity.__init__(self)
		EntityCommon.__init__(self)
		iRoomOperation.__init__(self)
		# 设置cell默认属性, 由base传递过来
		self.init_from_dict(self.userInfo)

		# Attention: 这个需要放在最后, onEnter会初始化适配器
		self.room = self.getCurrRoom()
		self.room.onEnter(self)

	def init_from_dict(self, b_dict):
		for k, v in b_dict.items():
			setattr(self, k, v)

	def initRoomAdapter(self, game_type, sit_idx):
		name = const.GameType2GameName[game_type]
		mod_name = "interfaces.{}_Adapter".format(name)
		mod = importlib.import_module(mod_name)
		adapter = mod.Adapter(sit_idx)
		MergePropertiesAndMethod(self, adapter)

	def isAvatar(self):
		return True

	@property
	def is_creator(self):
		# 新增一个房主标记位 代开房 和 玩家座位号会发生改变
		if self.room.room_type == const.NORMAL_ROOM:
			return self.idx == 0
		return False

	def showTip(self, tip):
		DEBUG_MSG("cell call showTip: {}".format(tip))
		if getattr(self, 'client', None):
			self.client.showTip(tip)

	def addGameCount(self, value=1):
		self.base.addGameCount(value)

	def updateOnlineStatus(self, status):
		DEBUG_MSG("Avatar[%i] userId[%d] updateOnlineStatus:[%d]" % (self.id, self.userId, status))
		if self.room:
			self.room.notify_player_online_status(self.userId, status)

	def clientReconnected(self):
		DEBUG_MSG("Avatar[%d]: client reconnected!" % (self.userId))
		self.updateOnlineStatus(1)
		if self.room:
			self.room.reqReconnect(self)

	def get_basic_user_info(self):
		return {
			'userID': self.userId,
			'nickname': self.nickname
		}

	def save_game_result(self, json_result):
		self.base.saveGameResult(json_result)
