# -*- coding: utf-8 -*-
import const

# ---------------------------- 开房参数检查 ----------------------------
"""
def XXX_CreateChecker(create_dict):
	return True of False
"""

def DummyChecker(*args):
	print("You need to implement a checker !!!")
	return False


def GXMJ_CreateChecker(create_dict):
	game_mode = create_dict['game_mode']
	game_round = create_dict['game_round']
	max_lose = create_dict['max_lose']
	lucky_num = create_dict['lucky_num']
	discard_seconds = create_dict['discard_seconds']
	hand_prepare = create_dict['hand_prepare']
	pay_mode = create_dict['pay_mode']
	room_type = create_dict['room_type']
	# Attention: 客户端传过来的数据都不可信, 必须检查一下
	if game_mode not in const.GAME_MODE \
			or game_round not in const.ROUND \
			or max_lose not in const.MAX_LOSE \
			or lucky_num not in const.TREASURE_NUM \
			or discard_seconds not in const.DISCARD_SECONDS \
			or pay_mode not in const.PAY_MODE \
			or room_type not in const.OPEN_ROOM_MODE \
			or hand_prepare not in const.PREPARE_MODE:
		return False
	return True


def roomParamsChecker(game_type, create_dict):
	name = const.GameType2GameName.get(game_type, None)
	if name is None:
		return False
	else:
		return globals().get("{}_CreateChecker".format(name), DummyChecker)(create_dict)

# ------------------------------------------------------------------------


# ----------------------------- 开房参数获取 ------------------------------
"""
def XXX_roomParams(create_dict):
	return a dict
"""

def GXMJ_roomParams(create_dict):
	return {
		'king_num' 			: 0,
		'player_num'		: 4,
		'game_round'		: create_dict['game_round'],
		'pay_mode' 			: create_dict['pay_mode'],
		'game_mode' 		: create_dict['game_mode'],
		'max_lose' 			: create_dict['max_lose'],
		'lucky_num' 		: create_dict['lucky_num'],
		'discard_seconds'	: create_dict['discard_seconds'],
		'hand_prepare'		: create_dict['hand_prepare'],
		'room_type'			: create_dict['room_type'],
	}


def roomParamsGetter(game_type, create_dict):
	name = const.GameType2GameName.get(game_type, None)
	if name is None:
		return None
	else:
		return globals()["{}_roomParams".format(name)](create_dict)

# ------------------------------------------------------------------------
