# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *
import const
import utility
import weakref
import x42
import switch
import json
from roomParamsHelper import roomParamsChecker, roomParamsGetter

class Table(object):

	def __init__(self, owner, club):
		self.owner = weakref.proxy(owner)
		self.club = club
		# 玩法和开放选项与桌子绑定
		self.gameType = None
		self.roomParams = None
		self.room = None
		# 每次重置为默认开房选项
		self.resetRoomParams()

	def getDetailInfo(self):
		if self.roomAvailable():
			return {
				'game_type': self.gameType,
				'room_params': json.dumps(self.roomParams),
				'seat_info': self.room.getSeatDetailInfo()
			}
		else:
			return {
				'game_type': self.gameType,
				'room_params': json.dumps(self.roomParams),
				'seat_info': []
			}

	def getAbstractInfo(self):
		if self.roomAvailable():
			return self.room.getSeatAbstractInfo()
		else:
			return 0

	def setRoomParams(self, game_type, room_params):
		self.gameType = game_type
		self.roomParams = room_params
		self.club.broadcastSeatInfo()

	def resetRoomParams(self):
		self.gameType = self.club.gameType
		self.roomParams = dict(self.club.roomType)

	def takeASeat(self, avatar):
		# 都调用avatar进入房间的接口, 统一入口
		if self.roomAvailable():
			avatar.enterRoom(self.room.roomID)
		else:
			def check_cb(result, msg=None):
				if not result:
					msg and avatar.showTip(msg)
					return
				if self.roomAvailable():
					avatar.enterRoom(self.room.roomID)
					return
				self.room = x42.GW.createRoom(self.gameType, self.roomParams)
				if self.room:
					self.room.club_table = weakref.proxy(self)
					avatar.enterRoom(self.room.roomID)
					msg and avatar.showTip(msg)
				else:
					ERROR_MSG("ClubTable takeASeat createRoom failed")

			self.cardCheck(avatar, check_cb)

	def roomAvailable(self):
		if self.room is None:
			return False

		return self.room.isDestroyed == False

	def roomDestroyed(self):
		self.room = None
		self.resetRoomParams()

	def cardCheck(self, avatar, callback):
		# 调试环境直接返回成功
		if switch.DEBUG_BASE > 0:
			callable(callback) and callback(True)
			return
		game_type = self.club.roomType['game_type']
		room_params = self.club.roomType['room_params']
		club_pay_mode = room_params['pay_mode']

		if club_pay_mode == const.AA_PAY_MODE:
			account = avatar.accountName

			def user_cb(content):
				DEBUG_MSG("cardCheck user_cb content is {}".format(content))
				if content is None:
					DEBUG_MSG("cardCheck user_cb content is None")
					callable(callback) and callback(False, "网络有点问题")
					return
				try:
					data = json.loads(content)
					# AA付费 自己房卡必须大于等于房间最低消耗数量, 否则不让玩家坐下游戏

					card_cost, diamond_cost = utility.calc_cost(game_type, room_params)
					if data["card"] >= card_cost:
						callable(callback) and callback(True, None)
					else:
						callable(callback) and callback(False, "您的房卡不足, 无法坐下游戏")
				except:
					import traceback
					ERROR_MSG(traceback.format_exc())
					callable(callback) and callback(False, "网络有点问题")

			utility.get_user_info(account, user_cb)
		elif club_pay_mode == const.CLUB_PAY_MODE:
			account = self.club.owner['accountName']

			def user_cb(content):
				DEBUG_MSG("cardCheck user_cb content is {}".format(content))
				if content is None:
					DEBUG_MSG("cardCheck user_cb content is None")
					callable(callback) and callback(False, "网络有点问题")
					return
				try:
					data = json.loads(content)
					# 亲友圈老板的房卡必须大于最低房卡数量, 否则不让玩家坐下游戏
					if data["card"] >= switch.CLUB_CARD_MIN:
						msg = None
						if data['card'] < switch.CLUB_CARD_WARN:
							msg = "亲友圈房卡即将不足, 请及时提醒亲友圈老板"
						callable(callback) and callback(True, msg)
					else:
						callable(callback) and callback(False, "亲友圈老板房卡不足, 无法坐下游戏")
				except:
					import traceback
					ERROR_MSG(traceback.format_exc())
					callable(callback) and callback(False, "网络有点问题")

			utility.get_user_info(account, user_cb)
		else:
			callable(callback) and callback(False, "扣卡方式不正确")


class TableManager(object):

	def __init__(self, club):
		self.club = weakref.proxy(club)
		self.tables = {}
		self.initTable()

	def initTable(self):
		for i in range(const.CLUB_TABLE_NUM):
			self.tables[i] = Table(self, self.club)

	def takeASeat(self, avatar_mb, t_idx):
		table = self.tables.get(t_idx)
		if table is None:
			avatar_mb.showTip("桌子编号错误")
			return
		table.takeASeat(avatar_mb)

	def changeTableRoomParams(self, avatar_mb, t_idx, game_type, create_json):
		table = self.tables.get(t_idx)
		if table is None:
			avatar_mb.showTip("桌子编号错误")
			return

		create_dict = json.loads(create_json)
		if not roomParamsChecker(game_type, create_dict):
			avatar_mb.showTip("房间参数错误")
			return

		room_params = roomParamsGetter(game_type, create_dict)
		room_params['owner_uid'] = self.club.owner['userId']
		room_params['club_id'] = self.club.clubId
		table.setRoomParams(game_type, room_params)
		# 改完直接进入房间
		table.takeASeat(avatar_mb)

	def getTableDetailInfo(self, t_idx):
		table = self.tables.get(t_idx)
		if table is None:
			return None
		return table.getDetailInfo()

	def getTable(self, t_idx):
		return self.tables.get(t_idx)

	def getTableListInfo(self):
		d_list = []
		for i in range(const.CLUB_TABLE_NUM):
			d_list.append(self.tables[i].getAbstractInfo())

		return d_list
