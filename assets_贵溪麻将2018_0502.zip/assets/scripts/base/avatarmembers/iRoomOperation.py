# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *
import const
import utility
import json
import switch
import x42
from roomParamsHelper import roomParamsChecker, roomParamsGetter

class iRoomOperation(object):
	""" 玩家游戏相关 """

	def __init__(self):
		self.room = None
		# 当前正在创建房间时再次请求创建需要拒绝
		self.req_entering_room = False

	def createRoom(self, game_type, create_json):
		create_dict = json.loads(create_json)
		DEBUG_MSG("create room args = {}".format(create_dict))
		if not roomParamsChecker(game_type, create_dict):
			return
		if self.req_entering_room:
			return
		if self.cell is not None:
			self.createRoomFailed(const.CREATE_FAILED_ALREADY_IN_ROOM)
			return

		self.req_entering_room = True

		def callback(content):
			if content is None:
				DEBUG_MSG("createRoom callback error: content is None, user id {}".format(self.userId))
				self.createRoomFailed(const.CREATE_FAILED_NET_SERVER_ERROR)
				return
			try:
				DEBUG_MSG("cards response: {}".format(content))
				if content[0] != '{':
					self.createRoomFailed(const.CREATE_FAILED_NET_SERVER_ERROR)
					return
				data = json.loads(content)
				card_cost, diamond_cost = utility.calc_cost(game_type, create_dict)
				if card_cost > data["card"] and diamond_cost > data["diamond"]:
					self.createRoomFailed(const.CREATE_FAILED_NO_ENOUGH_CARDS)
					return

				params = {
					'owner_uid'		: self.userId,
					'club_id'		: 0,
				}
				params.update(roomParamsGetter(game_type, create_dict))
				room = x42.GW.createRoom(game_type, params)
				if room:
					self.createRoomSucceed(room)
				else:
					self.createRoomFailed(const.CREATE_FAILED_OTHER)
			except:
				import traceback
				ERROR_MSG("createRoom callback content = {} error:{}".format(content, traceback.format_exc()))
				self.createRoomFailed(const.CREATE_FAILED_OTHER)

		if switch.DEBUG_BASE or x42.GW.isDailyActFree:
			callback('{"card":99, "diamond":9999}')
		else:
			utility.get_user_info(self.accountName, callback)

	def createRoomSucceed(self, room):
		self.req_entering_room = False
		self.room = room
		room.enterRoom(self, True)

	def createRoomFailed(self, err):
		self.req_entering_room = False
		if getattr(self, 'client', None):
			self.client.createRoomFailed(err)

	# c2s
	def enterRoom(self, roomID):
		if self.req_entering_room:
			DEBUG_MSG("iRoomOperation: enterRoom failed; entering or creating room")
			return
		if self.cell is not None:
			self.enterRoomFailed(const.ENTER_FAILED_ALREADY_IN_ROOM)
			return
		self.req_entering_room = True
		x42.GW.enterRoom(roomID, self)

	def enterRoomSucceed(self, room):
		self.req_entering_room = False
		self.room = room

	def enterRoomFailed(self, err):
		self.req_entering_room = False
		if getattr(self, 'client', None):
			self.client.enterRoomFailed(err)

	def leaveRoomSucceed(self):
		self.room = None

	def saveGameResult(self, json_r):
		# 保存玩家房间牌局战绩, 只保留最近10条记录
		DEBUG_MSG("saveGameResult: {}".format(len(self.game_history)))
		self.game_history.append(json_r)

		length = len(self.game_history)
		if length > const.MAX_HISTORY_RESULT:
			new_h = []
			for s in self.game_history:
				new_h.append(s)
			self.game_history = new_h[-const.MAX_HISTORY_RESULT:]

		self.writeToDB()
		if getattr(self, 'client', None):
			self.client.pushGameRecordList([json.loads(json_r)])

	def get_simple_client_dict(self):
		return {
			'head_icon': self.head_icon,
			'nickname': self.nickname,
			'sex': self.sex,
			'userId': self.userId,
			'uuid': self.uuid,
			'score': self.total_score,
		}
