# -*- coding: utf-8 -*-
from Room import Room


class GXMJ_Room(Room):

	def __init__(self):
		Room.__init__(self)

