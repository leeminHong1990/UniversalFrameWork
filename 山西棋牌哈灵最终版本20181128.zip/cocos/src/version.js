"use strict";

if (typeof app_version === 'undefined' ) {
    var app_version = "1.1.0";
}