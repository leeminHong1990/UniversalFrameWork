"use strict";
/*-----------------------------------------------------------------------------------------
												interface
-----------------------------------------------------------------------------------------*/
var impCell = impRoomOperation.extend({
    __init__: function () {
        this._super();
        KBEngine.DEBUG_MSG("Create impCell");
    },
});