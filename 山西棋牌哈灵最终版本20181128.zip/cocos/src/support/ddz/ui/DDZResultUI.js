var DDZResultUI = PokerResultUI.extend({

});