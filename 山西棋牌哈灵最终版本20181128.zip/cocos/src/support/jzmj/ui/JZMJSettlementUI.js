"use strict"
var JZMJSettlementUI = SettlementUI.extend({

});
