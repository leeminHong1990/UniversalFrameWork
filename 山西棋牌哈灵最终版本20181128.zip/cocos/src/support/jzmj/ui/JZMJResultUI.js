var JZMJResultUI = ResultUI.extend({
	ctor:function() {
		this._super();
	}

});
