var LLKDDMJResultUI = ResultUI.extend({
	ctor:function() {
		this._super();
	}
	
});
