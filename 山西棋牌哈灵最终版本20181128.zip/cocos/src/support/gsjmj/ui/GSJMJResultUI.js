var GSJMJResultUI = ResultUI.extend({
	ctor: function () {
		this._super();
	}

});
