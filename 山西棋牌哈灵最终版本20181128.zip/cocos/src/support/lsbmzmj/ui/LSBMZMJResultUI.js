var LSBMZMJResultUI = ResultUI.extend({
	ctor:function() {
		this._super();
	}
	
});
