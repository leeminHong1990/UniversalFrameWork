var TYKDDMJResultUI = ResultUI.extend({
	ctor:function() {
		this._super();
	}
	
});
