var TDHMJResultUI = ResultUI.extend({
	ctor:function() {
		this._super();
	}
	
});
