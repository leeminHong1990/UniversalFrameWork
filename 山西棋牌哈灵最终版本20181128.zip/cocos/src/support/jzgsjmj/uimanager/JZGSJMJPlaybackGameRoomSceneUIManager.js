var JZGSJMJPlaybackGameRoomSceneUIManager = JZMJPlaybackGameRoomSceneUIManager.extend({});
