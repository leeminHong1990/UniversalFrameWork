var JZGSJMJGameRoomSceneUIManager = JZMJGameRoomSceneUIManager.extend({

});
