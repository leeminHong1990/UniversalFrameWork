// cc.loader.loadJs("src/views/uimanager/LoginSceneUIManager.js")

var JZGSJMJGameRoomScene = JZMJGameRoomScene.extend({
	className: "JZGSJMJGameRoomScene",
});
