var JZGSJMJPlaybackGameRoomScene = JZMJPlaybackGameRoomScene.extend({
	className: "JZGSJMJPlaybackGameRoomScene",
});
